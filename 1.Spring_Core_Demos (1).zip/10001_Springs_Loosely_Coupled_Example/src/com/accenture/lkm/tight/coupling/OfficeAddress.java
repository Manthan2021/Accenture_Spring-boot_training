package com.accenture.lkm.tight.coupling;

public class OfficeAddress extends Address{

	private String officeName;

	public String getOfficeName() {
		return officeName;
	}

	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}
	
}

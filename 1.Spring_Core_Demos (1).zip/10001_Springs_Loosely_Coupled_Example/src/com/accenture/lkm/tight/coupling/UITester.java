package com.accenture.lkm.tight.coupling;

public class UITester {

	public static void main(String[] args) {
		
		Employee employee = new Employee();
		employee.setEmployeeId(1001);
		employee.setSalary(56000.0);
		employee.getAddress().setAddressLine1("Hyderabad");
		employee.getAddress().setAddressLine2("Telangana");
		
		employee.display();
	}
}

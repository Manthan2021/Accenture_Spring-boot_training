package com.accenture.lkm.looselycoupled;

public class OfficeAddress extends Address{

	private String officeName;

	public String getOfficeName() {
		return officeName;
	}

	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}
	
}

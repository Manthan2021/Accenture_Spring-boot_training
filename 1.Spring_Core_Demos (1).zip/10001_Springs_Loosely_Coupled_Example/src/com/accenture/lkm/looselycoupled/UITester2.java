package com.accenture.lkm.looselycoupled;

public class UITester2 {

	public static void main(String[] args) {
		OfficeAddress address=new OfficeAddress();
		address.setAddressLine1("Waverock, Gachibowli");
		address.setAddressLine2("Hyderabad, Telangana");
		address.setOfficeName("Accenture");
		
		Employee employee = new Employee(address);
		employee.setEmployeeId(1001);
		employee.setSalary(56000.0);
		
		employee.display();
	}
}

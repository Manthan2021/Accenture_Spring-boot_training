package com.accenture.lkm.looselycoupled;

public class UITester {

	public static void main(String[] args) {
		Address address=new Address();
		address.setAddressLine1("Hyderabad");
		address.setAddressLine2("Telangana");
		
		
		Employee employee = new Employee(address);
		employee.setEmployeeId(1001);
		employee.setSalary(56000.0);
		
		
		employee.display();
	}
}

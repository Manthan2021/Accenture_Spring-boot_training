package com.accenture.lkm.looselycoupled;

class Employee {

	private Address address;//HAS - A
	private Integer employeeId;
	private Double salary;

	public Employee(Address address) {
		/* Employee class is now not creating the object of Address class
		 	instead it is accepting as a parameter*/
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public void display() {
		System.out.println("Employee Details are:");
		System.out.println("Employee ID : " + this.employeeId);
		System.out.println("Employee Salary : " + this.salary);
		System.out.println("Address line1 : " + this.address.getAddressLine1());
		System.out.println("Address line2 : " + this.address.getAddressLine2());
	}
}
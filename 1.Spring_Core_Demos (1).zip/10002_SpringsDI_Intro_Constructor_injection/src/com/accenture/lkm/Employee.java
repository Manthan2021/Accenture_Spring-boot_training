package com.accenture.lkm;

public class Employee {

	private Integer employeeId;
	private String employeeName;
	private Double salary;

	private Address address;

	public Employee(Integer employeeId, String employeeName, Double salary, Address address) {
		super();
		System.out.println("Employee Class Parameterized Constructor....");
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.address = address;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public Double getSalary() {
		return salary;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public Address getAddress() {
		return address;
	}

	public void display() {
		System.out.println("\nEmployee Details are:");
		System.out.println("Employee ID:" + this.employeeId);
		System.out.println("Employee Name:" + this.employeeName);
		System.out.println("Employee Salary:" + this.salary);
		System.out.println("\nAddress line1:" + this.address.getAddressLine1());
		System.out.println("Address line2:" + this.address.getAddressLine2());
	}
}
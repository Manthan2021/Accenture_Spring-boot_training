package com.accenture.lkm.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.accenture.lkm.Address;
import com.accenture.lkm.Employee;

@Configuration
public class MyConfiguration {
	@Bean(name="employee")
	public Employee createEmployee(Address address){//Managed Parameter
		Employee  employee = new Employee();
		employee.setEmployeeId(1001);    
		employee.setEmployeeName("JAS");
		employee.setSalary(56000.0);
		employee.setAddress(address);
		return  employee;
	}
	@Bean(name="address")
	public Address createAddress(){
		Address address = new Address();
		address.setAddressLine1("AddressLine1");
		address.setAddressLine2("AddressLine2");
		return address;
	}
}

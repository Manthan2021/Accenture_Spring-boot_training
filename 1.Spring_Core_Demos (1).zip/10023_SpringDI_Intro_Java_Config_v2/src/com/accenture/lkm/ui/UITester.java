package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.accenture.lkm.Employee;
import com.accenture.lkm.resources.MyConfiguration;

public class UITester {
	public static void main(String[] args) {
	
		ApplicationContext applicationContext = 
				new AnnotationConfigApplicationContext(MyConfiguration.class); 
		Employee employee = applicationContext.getBean("employee",Employee.class);
		employee.display();
		
		((AnnotationConfigApplicationContext)applicationContext).close();
	}
}

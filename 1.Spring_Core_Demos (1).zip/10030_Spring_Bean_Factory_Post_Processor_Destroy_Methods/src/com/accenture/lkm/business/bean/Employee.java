package com.accenture.lkm.business.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;


public class Employee implements InitializingBean,DisposableBean {
	
	private String firstName;	
	private String lastName;

	public Employee() {
		System.out.println("1. constructor");
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("2. setter");
	}

	@PostConstruct
	private void postConstruct() {
		System.out.println("4. postConstruct()");
	}
	@PreDestroy
	private void preDestroy() {
		System.out.println("8. PreDestroy destroy()");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("5. afterPropertiesSet()");
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("9. DisposalBean destroy()");
		
	}
	public void myInit() {
		System.out.println("6. init()");
	}
	public void myDestroy() {
		System.out.println("10. myDestroy destroy()");
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + "]";
	}


}
package com.accenture.lkm.ui;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.business.bean.Employee;

public class UITester {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new 
				ClassPathXmlApplicationContext("com/accenture/lkm/resources/my_springbean.xml");
		
		Employee employee = context.getBean("employee",Employee.class);
		System.out.println(employee);
		
		System.out.println("Closing the Context");
		context.close();	
	}

}
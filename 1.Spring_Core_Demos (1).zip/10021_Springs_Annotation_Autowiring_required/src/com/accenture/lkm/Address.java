package com.accenture.lkm;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component("address")
public class Address {

	//@Value("Hyderabad")
	private String addressLine1;
	//@Value("Telangana")
	private String addressLine2;

	public Address() {
		System.out.println("Address Class Constructor....");
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		System.out.println("From Setter of Address Line1");
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		System.out.println("From Setter of Address Line2");
		this.addressLine2 = addressLine2;
	}

}

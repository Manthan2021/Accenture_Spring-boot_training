package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.Employee;

public class UITester {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new 
				ClassPathXmlApplicationContext("com/accenture/lkm/resources/my_springbean.xml");
		
		Employee employee = applicationContext.getBean("employee",Employee.class);
		employee.display();
		
		
		((ClassPathXmlApplicationContext)applicationContext).close();
	}

}
/*
 * For non implicit reference type order of parameters 
 * and order of Constructor-arg in xml doesn't matter
 */

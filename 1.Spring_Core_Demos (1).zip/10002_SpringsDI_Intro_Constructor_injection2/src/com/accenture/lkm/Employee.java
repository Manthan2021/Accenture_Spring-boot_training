package com.accenture.lkm;

public class Employee {

	private Integer employeeId;
	private String employeeName;
	private Double salary;

	private Address address;
	private Contact contact;

	public Employee(Address address,Contact contact) {
		super();
		System.out.println("Employee Class Parameterized Constructor....");
		this.address=address;
		this.contact=contact;
	}

	
	public Integer getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public Double getSalary() {
		return salary;
	}


	public void setSalary(Double salary) {
		this.salary = salary;
	}


	public Address getAddress() {
		return address;
	}


	public Contact getContact() {
		return contact;
	}


	public void display() {
		System.out.println("\nEmployee Details are:");
		System.out.println("Employee ID:" + this.employeeId);
		System.out.println("Employee Name:" + this.employeeName);
		System.out.println("Employee Salary:" + this.salary);
		
		System.out.println("\nAddress line1:" + this.address.getAddressLine1());
		System.out.println("Address line2:" + this.address.getAddressLine2());
		
		System.out.println("\nEmail:" + this.contact.getEmail());
		System.out.println("Phone number:" + this.contact.getPhoneNumber());
	}
}
package com.accenture.lkm;

public class Contact {
	private String email;
	private String phoneNumber;

	public Contact(String email, String phoneNumber) {
		super();
		System.out.println("Contact Class Parameterized Constructor....");
		this.email = email;
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

}

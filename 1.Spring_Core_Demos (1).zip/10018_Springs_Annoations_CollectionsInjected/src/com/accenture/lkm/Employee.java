package com.accenture.lkm;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("employee")
public class Employee {
	
	@Value("1001")
	private Integer employeeId;
	
	@Value("56000.0")
	private Double salary;
	
	@Value("#{address}")
	private Address address;

	

	/* Collection Properties */
	@Value("#{feedValuesBean.listPropertyFromFeeder}") // List: [apple, boy]
	private List<Object> listProperty;

	@Value("#{feedValuesBean.mapPropertyFromFeeder}") // Map: {tom=tom@gmail.com, mike=mike@gmail.com}
	private Map<String, String> mapProperty;

	@Value("#{feedValuesBean.listPropertyFromFeeder[0]}") // apple
	private String employeeName;

	@Value("#{feedValuesBean.mapPropertyFromFeeder[tom]}") // tom@gmail.com
	private String email;
	/* Collection Properties */

	public Employee() {
		System.out.println("From Constructor of Employee: Created the Employee Object and injected the Address Object\n");
	}


	public void display() {
		System.out.println("\nEmployee Details are:");
		System.out.println("Employee ID:" + this.employeeId);
		System.out.println("Employee Name : " + this.employeeName);
		System.out.println("Employee Salary:" + this.salary);
		System.out.println("Email : " + this.email);
		
		System.out.println("\nAddress line1:" + this.address.getAddressLine1());
		System.out.println("Address line2:" + this.address.getAddressLine2());
		
		System.out.println("\nList:"+listProperty);
		System.out.println("Map:"+mapProperty);
	}
}
package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.Employee;

public class UITester {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new 
				ClassPathXmlApplicationContext("com/accenture/lkm/resources/my_springbean.xml");
		
		Employee employee1 = applicationContext.getBean("employee1",Employee.class);
		employee1.display();
		
		Employee employee2 = applicationContext.getBean("employee2",Employee.class);
		employee2.display();

		((ClassPathXmlApplicationContext)applicationContext).close();
	}

}

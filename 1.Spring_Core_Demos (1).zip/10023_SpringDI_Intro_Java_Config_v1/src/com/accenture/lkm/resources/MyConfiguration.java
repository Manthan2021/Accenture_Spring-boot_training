package com.accenture.lkm.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.accenture.lkm.Address;
import com.accenture.lkm.Employee;

@Configuration
public class MyConfiguration {
	
	@Bean
	//if Bean name is not given then the bean is created by the name of the method
	//here it is createEmployee
	public Employee createEmployee(){
		Employee  employee = new Employee();
		employee.setEmployeeId(1001);    
		employee.setEmployeeName("JAS");
		employee.setSalary(56000.0);
		employee.setAddress(createAddress());
		return employee;
	}
	
	@Bean(name="address")
	public Address createAddress(){
		Address address = new Address();
		address.setAddressLine1("AddressLine1");
		address.setAddressLine2("AddressLine2");
		return address;
	}
}

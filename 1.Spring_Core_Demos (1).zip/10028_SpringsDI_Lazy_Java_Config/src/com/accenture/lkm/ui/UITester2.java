package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.accenture.lkm.resources.MyConfiguration2;

public class UITester2 {

	public static void main(String[] args) {

		ApplicationContext applicationContext = 
				new AnnotationConfigApplicationContext(MyConfiguration2.class);
		
		((AnnotationConfigApplicationContext)applicationContext).close();
	}
}
/*
 * Employee Object is not created as it is configured as LAZY
 */

package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.accenture.lkm.resources.MyConfiguration1;

public class UITester {

	public static void main(String[] args) {

		ApplicationContext applicationContext = 
				new AnnotationConfigApplicationContext(MyConfiguration1.class);
		
		((AnnotationConfigApplicationContext)applicationContext).close();
	}

}
//All beans are initialized eagerly
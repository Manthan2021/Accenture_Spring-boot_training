package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.accenture.lkm.Employee;
import com.accenture.lkm.resources.MyConfiguration2;

public class UITester3 {

	public static void main(String[] args) {

		ApplicationContext applicationContext = 
				new AnnotationConfigApplicationContext(MyConfiguration2.class);
		
		System.out.println("**** AT LINE 15*****");
		Employee employee = (Employee) applicationContext.getBean("employee");
		employee.display();
		
		((AnnotationConfigApplicationContext)applicationContext).close();
	}

}
/*
 * Employee Object is created after Line 15 when it is actually needed/called
 */

package com.accenture.lkm.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import com.accenture.lkm.Employee;

@Configuration

public class MyConfiguration2 {

	@Bean(name="employee")
	@Lazy(value=true)
	public Employee createEmployee() {
		Employee employee = new Employee();
		employee.setEmployeeId(1001);
		employee.setEmployeeName("JAS");
		employee.setSalary(1900.0);
		return employee;
	}

	
}

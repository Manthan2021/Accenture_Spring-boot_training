package com.accenture.lkm.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.accenture.lkm.Employee;

@Configuration
public class MyConfiguration1 {

	@Bean
	public Employee createEmployee() {
		Employee employee = new Employee();
		employee.setEmployeeId(1001);
		employee.setEmployeeName("JAS");
		employee.setSalary(1900.0);
		return employee;
	}

	
}

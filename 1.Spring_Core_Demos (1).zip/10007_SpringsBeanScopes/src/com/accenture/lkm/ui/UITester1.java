package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.Employee;

public class UITester1 {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new 
				ClassPathXmlApplicationContext("com/accenture/lkm/resources/my_springbean1.xml");
		
		Employee employee1 = applicationContext.getBean("employee",Employee.class);
		Employee employee2 = applicationContext.getBean("employee",Employee.class);
		Employee employee3 = applicationContext.getBean("employee",Employee.class);
		Employee employee4 = applicationContext.getBean("employee",Employee.class);
		
		System.out.println(employee1.hashCode());
		System.out.println(employee2.hashCode());
		System.out.println(employee3.hashCode());
		System.out.println(employee4.hashCode());
		
		((ClassPathXmlApplicationContext)applicationContext).close();
	}

}

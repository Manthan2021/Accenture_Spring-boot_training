package com.accenture.lkm;

public class Employee {

	private Integer employeeId;
	private String employeeName;
	private Double salary;
	
	public Employee() {
		System.out.println("Constructor of Employee class..");
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

}
package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.Employee;

public class UITester3 {

	public static void main(String[] args) {

		ApplicationContext applicationContext = 
				new ClassPathXmlApplicationContext("com/accenture/lkm/resources/my_springbean2.xml");
		
		System.out.println("**** AT LINE 15*****");
		Employee employee = (Employee) applicationContext.getBean("employee");
		employee.display();
		
		((ClassPathXmlApplicationContext)applicationContext).close();
	}

}
/*
 * Employee Object is created after Line 15 when it is actually needed/called
 */

package com.accenture.lkm;

public class Employee {

	private Integer employeeId;
	private Double salary;
	private String employeeName;
	

	public Employee() {
		System.out.println("Employee class Constructor");
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public void display() {
		System.out.println("\nEmployee Details are:");
		System.out.println("Employee ID:" + this.employeeId);
		System.out.println("Employee Name:"+this.employeeName);
		System.out.println("Employee Salary:" + this.salary);
	}
}
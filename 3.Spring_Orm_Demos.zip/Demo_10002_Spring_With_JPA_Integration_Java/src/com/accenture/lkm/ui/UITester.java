package com.accenture.lkm.ui;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.service.EmployeeService;
import com.accenture.lkm.spring.mainconf.SpringMainConfig;

public class UITester {

	public static void main(String[] args) {

		EmployeeService employeeService = null;
		try {

			ApplicationContext applicationContext = new AnnotationConfigApplicationContext(SpringMainConfig.class);
			employeeService = applicationContext.getBean("employeeServiceImpl",EmployeeService.class);
			
			// 1 Add Employee
			addEmployee(employeeService);

			// 2 Get Employee Employee
			getEmployeeDetails(employeeService);
			
			// 3 Update Employee
			updateEmployeeDetails(employeeService);

			// 4 Delete Employee
			deleteEmployee(employeeService);

			// 5 Get All
			getAllEmployeeDetails(employeeService);

			((AnnotationConfigApplicationContext) applicationContext).close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void addEmployee(EmployeeService serviceImpl) {

		EmployeeBean bean = new EmployeeBean();
		bean.setInsertTime(new Date());
		bean.setName("New Employee");
		bean.setRole("Sr.Analyst");
		bean.setSalary(10.0);
		try {
			int id = serviceImpl.addEmployee(bean);
			System.out.println("Employee Registered Successfully: " + id);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void getEmployeeDetails(EmployeeService serviceImpl) {

		try {
			EmployeeBean employeeBean = serviceImpl.getEmployeeDetails(1003);
			if (employeeBean != null) {
				System.out.println("Employee Details");
				System.out.println("================");
				System.out.println("Name: " + employeeBean.getName());
				System.out.println("Salary: " + employeeBean.getSalary());
				System.out.println("Role: " + employeeBean.getRole());
			} else {
				System.out.println("Invalid Employee Id");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void updateEmployeeDetails(EmployeeService serviceImpl) {

		try {

			EmployeeBean employeeBean = new EmployeeBean();
			employeeBean.setId(1002);
			employeeBean.setSalary(1235.4);
			
			EmployeeBean updatedEmployeeBean = serviceImpl.updateEmployeeDetails(employeeBean);
			if(updatedEmployeeBean!=null) {
				System.out.println("Updated Employee Details");
				System.out.println("========================");
				System.out.println("Id: "+updatedEmployeeBean.getId());
				System.out.println("Name: " + updatedEmployeeBean.getName());
				System.out.println("Salary: " + updatedEmployeeBean.getSalary());
				System.out.println("Role: " + updatedEmployeeBean.getRole());
			}else {
				System.out.println("Invalid Employee Id");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void deleteEmployee(EmployeeService employeeService) {

		try {
			EmployeeBean employeeBean = employeeService.deleteEmployeeDetails(1004);
			if (employeeBean != null) {
				System.out.println("Deleted Employee Details");
				System.out.println("========================");
				System.out.println("Id: "+employeeBean.getId());
				System.out.println("Name: " + employeeBean.getName());
				System.out.println("Salary: " + employeeBean.getSalary());
				System.out.println("Role: " + employeeBean.getRole());
			} else {
				System.out.println("Invalid Employee Id");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void getAllEmployeeDetails(EmployeeService employeeService) {
		try {
			employeeService.getEmployeeList().forEach(System.out::println);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
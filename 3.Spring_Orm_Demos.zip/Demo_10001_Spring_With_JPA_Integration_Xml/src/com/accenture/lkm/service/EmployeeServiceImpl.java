package com.accenture.lkm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.dao.EmployeeDAO;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;

	public Integer addEmployee(EmployeeBean employeeBean) throws Exception {
		return employeeDAO.addEmployee(employeeBean);
	}

	public EmployeeBean getEmployeeDetails(Integer id) throws Exception {
		return employeeDAO.getEmployeeDetails(id);
	}

	public EmployeeBean updateEmployeeDetails(EmployeeBean employeeBean) throws Exception {
		return employeeDAO.updateEmployeeDetails(employeeBean);
	}

	public EmployeeBean deleteEmployeeDetails(Integer id) throws Exception {
		return employeeDAO.deleteEmployeeDetails(id);
	}

	public List<EmployeeBean> getEmployeeList() throws Exception {
		return employeeDAO.getEmployeeList();
	}

}

package com.accenture.lkm.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.entity.EmployeeEntity;

@Repository
@Transactional(value = "txManager")
public class EmployeeDAOImpl implements EmployeeDAO {

	@PersistenceContext
	// @PersistenceContext(type = PersistenceContextType.TRANSACTION)
	// @PersistenceContext(type = PersistenceContextType.EXTENDED)
	private EntityManager entityManager;

	public EmployeeBean getEmployeeDetails(Integer id) throws Exception {
		EmployeeBean employeeBean = null;

		try {

			EmployeeEntity employeeEntity = entityManager.find(EmployeeEntity.class, id);

			if (employeeEntity != null) {
				employeeBean = convertEntityToBean(employeeEntity);
			}

		} catch (Exception exception) {

			throw exception;
		}

		return employeeBean;
	}

	public static EmployeeBean convertEntityToBean(EmployeeEntity entity) {
		EmployeeBean employee = new EmployeeBean();
		BeanUtils.copyProperties(entity, employee);
		return employee;
	}

}

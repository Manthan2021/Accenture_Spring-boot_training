package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.service.EmployeeService;

public class UITester {

	public static void main(String[] args) {

		EmployeeService employeeService = null;
		try {

			ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
					"com/accenture/lkm/resources/cst-main-config.xml");
			employeeService = applicationContext.getBean("employeeServiceImpl", EmployeeService.class);

			getEmployeeDetails(employeeService, 1003);
			getEmployeeDetails(employeeService, 1004);

			((ClassPathXmlApplicationContext) applicationContext).close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void getEmployeeDetails(EmployeeService serviceImpl, int empId) {

		try {

			EmployeeBean employeeBean = serviceImpl.getEmployeeDetails(empId);

			if (employeeBean == null) {
				System.out.println("Invalid Employee Id");
			} else {
				System.out.println("Employee Details");
				System.out.println("================");
				System.out.println("Name: " + employeeBean.getName());
				System.out.println("Salary: " + employeeBean.getSalary());
				System.out.println("Role: " + employeeBean.getRole());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}
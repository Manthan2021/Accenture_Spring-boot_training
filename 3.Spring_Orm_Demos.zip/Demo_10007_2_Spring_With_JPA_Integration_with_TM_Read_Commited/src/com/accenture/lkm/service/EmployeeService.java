package com.accenture.lkm.service;

import com.accenture.lkm.business.bean.EmployeeBean;

public interface EmployeeService {

	EmployeeBean getEmployeeDetails(Integer id) throws Exception;

}

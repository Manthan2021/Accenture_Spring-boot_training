package com.accenture.lkm.dao;

import com.accenture.lkm.business.bean.EmployeeBean;

public interface EmployeeDAO {

	EmployeeBean getEmployeeDetails(Integer id) throws Exception;

}
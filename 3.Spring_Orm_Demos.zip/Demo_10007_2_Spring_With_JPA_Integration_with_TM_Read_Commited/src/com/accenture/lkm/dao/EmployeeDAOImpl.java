package com.accenture.lkm.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.entity.EmployeeEntity;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional(value = "txManager", isolation = Isolation.READ_COMMITTED)
	public EmployeeBean getEmployeeDetails(Integer id) throws Exception {
		EmployeeBean employeeBean = null;

		try {

			EmployeeEntity employeeEntity = entityManager.find(EmployeeEntity.class, id);

			if (employeeEntity != null) {
				employeeBean = convertEntityToBean(employeeEntity);
			}

		} catch (Exception exception) {

			throw exception;
		}

		return employeeBean;
	}

	public static EmployeeBean convertEntityToBean(EmployeeEntity entity) {
		EmployeeBean employee = new EmployeeBean();
		BeanUtils.copyProperties(entity, employee);
		return employee;
	}
}

package com.accenture.lkm.service;

import com.accenture.lkm.business.bean.EmployeeBean;

public interface EmployeeService {

	Integer addEmployee(EmployeeBean employeeBean) throws Exception;

}

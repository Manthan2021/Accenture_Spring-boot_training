package com.accenture.lkm.ui;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.service.EmployeeService;

public class UITester {

	public static void main(String[] args) {
		
		EmployeeService employeeService=null;
		try{
			
			ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/accenture/lkm/resources/cst-main-config.xml");
			employeeService = applicationContext.getBean("employeeServiceImpl",EmployeeService.class);

			// 1 Add Employee
			addEmployee(employeeService);
			
			((ClassPathXmlApplicationContext)applicationContext).close();
		
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public static void addEmployee(EmployeeService serviceImpl) {

		EmployeeBean bean = new EmployeeBean();
		bean.setInsertTime(new Date());
		bean.setName("New Employee");
		bean.setRole("Sr.Analyst");
		bean.setSalary(10.0);
		try {

			int id = serviceImpl.addEmployee(bean);
			System.out.println("Employee Registered Successfully: " + id);
	
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}
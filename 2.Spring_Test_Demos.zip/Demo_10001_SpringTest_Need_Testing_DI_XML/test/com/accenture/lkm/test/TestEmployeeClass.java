package com.accenture.lkm.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.Employee;

public class TestEmployeeClass {

	@Test
	public void testEmployee() {
		System.out.println("*** testEmployee ***");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"com/accenture/lkm/resources/my_springbean.xml");
		Employee employee = applicationContext.getBean("employee",Employee.class);
		Assertions.assertNotNull(employee);
		((ClassPathXmlApplicationContext)applicationContext).close();
	}
	
	@Test
	public void testEmployeeAddress() {
		System.out.println("*** testEmployeeAddress ***");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"com/accenture/lkm/resources/my_springbean.xml");
		Employee employee = applicationContext.getBean("employee",Employee.class);
		Assertions.assertNotNull(employee.getAddress());
		((ClassPathXmlApplicationContext)applicationContext).close();
	}

	@Test
	public void testEmployeeSalary() {
		System.out.println("*** testEmployeeSalary ***");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"com/accenture/lkm/resources/my_springbean.xml");
		Employee employee = applicationContext.getBean("employee",Employee.class);
		Assertions.assertEquals(200000,employee.getSalary());
		((ClassPathXmlApplicationContext)applicationContext).close();
	}
}
// draw backs:
//1.For every methods Application context is reloaded, and support for context management 
// and caching is not there

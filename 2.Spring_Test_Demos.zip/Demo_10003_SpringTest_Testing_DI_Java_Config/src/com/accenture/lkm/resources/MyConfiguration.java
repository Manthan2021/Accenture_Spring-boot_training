package com.accenture.lkm.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.accenture.lkm.Address;
import com.accenture.lkm.Employee;

@Configuration
public class MyConfiguration {
	
	@Bean(name = "employee")
	public Employee createEmployee(Address address){
		Employee  employee = new Employee(address);
		employee.setEmployeeId(1001);
		employee.setEmployeeName("JAS");
		employee.setSalary(200000.0);
		return  employee;
	}

	@Bean(name="address")
	public Address createAddress(){
		Address address=new Address();
		address.setAddressLine1("HSR Layout, Sector1");
		address.setAddressLine2("Bangalore, Karnatka");
		return address;
	}
}
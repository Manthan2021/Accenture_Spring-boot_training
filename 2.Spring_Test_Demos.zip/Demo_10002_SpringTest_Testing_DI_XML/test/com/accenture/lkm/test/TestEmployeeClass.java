package com.accenture.lkm.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.accenture.lkm.Employee;

/*
 * The @ExtendWith annotation is used in JUnit 5 to register extensions (also known as "test instance post-processors"). 
 * When you use @ExtendWith(SpringExtension.class), you're essentially telling JUnit to enable Spring support for the test 
 * class.
 */
@ExtendWith(SpringExtension.class)

/*
 * The @ContextConfiguration annotation in Spring test framework is used to specify the locations of the configuration files 
 * that define the application context for the test.
 * The Application context is loaded only once, and cached for all the test methods 
 */
@ContextConfiguration(locations = "/com/accenture/lkm/resources/my_springbean.xml")
public class TestEmployeeClass {

	@Autowired
	private Employee employee;
	
	@Test
	public void testEmployee() {
		System.out.println("*** testEmployee ***");
		Assertions.assertNotNull(employee);
	}
	
	@Test
	public void testEmployeeAddress() {
		System.out.println("*** testEmployeeAddress ***");
		Assertions.assertNotNull(employee.getAddress());
	}

	@Test
	public void testEmployeeSalary() {
		System.out.println("*** testEmployeeSalary ***");
		Assertions.assertEquals(200000,employee.getSalary());
	}
}
// draw backs fixed:
//1.For every methods Application context is reloaded, and support for context management 
// and caching is not there

//https://docs.spring.io/spring-batch/trunk/reference/html/testing.html
//https://docs.spring.io/spring/docs/4.2.4.RELEASE/spring-framework-reference/htmlsingle/#testing-introduction
